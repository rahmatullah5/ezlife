<html>
	<head>
	</head>
	<body>
		<form action="../controller/function.php?insert=user_register" method="post" enctype="multipart/form-data">
			<table>
				<tr>
					<td colspan="2">Register Sederhana</td>
				</tr>
				<tr>
					<td>Username</td>
					<td><input type="text" name="username" required="required"  pattern=".{6,15}" title="6 sampai 15 Karakter" maxlength="15"></td>
				</tr>
				<tr>
					<td>Password</td>
					<td><input type="password" name="password" required="required"  pattern=".{6,15}" title="6 sampai 15 Karakter" maxlength="15"></td>
				</tr>
				<tr>
					<td>Nama Lengkap</td>
					<td><input type="text" name="nama" required="required" pattern=".{2,25}" title="2 sampai 25 Karakter" maxlength="25"></td>
				</tr>
				<tr>
					<td>Email</td>
					<td><input type="email" name="email" maxlength="50"></td>
				</tr>
				<tr>
					<td>Pekerjaan</td>
					<td><input type="text" name="pekerjaan" required="required" pattern=".{2,25}" title="2 sampai 25 Karakter" maxlength="25"></td>
				</tr>
				<tr>
					<td>Gender</td>
					<td>
						<select name="gender" required="required">
							<option value="pria">Pria</option>
							<option value="wanita">Wanita</option>
							<option value="lainnya">Lainya</option>
						</select>
					</td>
				</tr>
				<tr>
					<td>Foto</td>
					<td><input type="file" name="foto" id="foto"></td>
				</tr>
				<tr>
					<td><input type="submit" name="s_button"></td>
					<td><input type="reset" name="r_button"></td>
				</tr>
				
			</table>
		</form>
		
	</body>
</html>