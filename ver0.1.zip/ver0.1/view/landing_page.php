<html>
	<head>
	<head>
	<body>
		<form action="../controller/function.php?cek=cek_login" method="post">
			<table>
			<tr>
				<td colspan="2">Form Login Sederhana</td>
			</tr>
			<tr>
				<td>Username</td>
				<td><input type="text" name="username" required="required"  pattern=".{6,15}" title="6 sampai 15 Karakter"></td>
			</tr>
			<tr>
				<td>Password</td>
				<td><input type="password" name="password" required="required"  pattern=".{6,15}" title="6 sampai 15 Karakter"></td>
			</tr>
			<tr>
				<td><input type="submit" name="s_button"></td>
				<td><input type="reset" name="r_button"></td>
			</tr>
			<tr>
				<td><a href="#">Buat Akun</a></td>
			</tr>
			</table>
		</form>
	</body>
</html>