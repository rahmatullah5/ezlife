<?php 
	include "connection.php";
	//Case Validasi Data
	switch($_GET['cek']){
		case "cek_login":
		if(isset($_POST['s_button'])){
			$username=htmlspecialchars($_POST['username']);
			$password=htmlspecialchars($_POST['password']);
			
			$query=mysqli_query($con , "select * from user where username='$username' and password='$password'");
			$row=mysqli_num_rows($query);
			echo $row;
			if($row!=0){
				header("location:../model/main.php?p=user_profile");
			}
			else{
				echo "Who are you";
			}
			
			
		}
		break;
	}
	
	//Case Insert Data
	switch($_GET['insert']){
		case 'user_register':
		$username=htmlspecialchars($_POST['username']);	
		$password=htmlspecialchars($_POST['password']);	
		$nama=htmlspecialchars($_POST['nama']);
		$email=htmlspecialchars($_POST['email']);	
		$pekerjaan=htmlspecialchars($_POST['pekerjaan']);	
		$gender=htmlspecialchars($_POST['gender']);
		$foto=htmlspecialchars($_FILES["foto"]["name"]);
		
		$target_dir = "../view/_assets/images/_default/";
		$target_file = $target_dir . basename($foto);
		$uploadOk = 1;
		$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
		// Check if image file is a actual image or fake image
		if(isset($_POST["submit"])) {
			$check = getimagesize($_FILES["foto"]["tmp_name"]);
			if($check !== false) {
				echo "File is an image - " . $check["mime"] . ".";
				$uploadOk = 1;
			} else {
				echo "File is not an image.";
				$uploadOk = 0;
			}
		}
		// Check if file already exists
		if (file_exists($target_file)) {
			echo "Sorry, file already exists.";
			$uploadOk = 0;
		}
		// Check file size
		if ($_FILES["foto"]["size"] > 500000) {
			echo "Sorry, your file is too large.";
			$uploadOk = 0;
		}
		// Allow certain file formats
		if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
		&& $imageFileType != "gif" ) {
			echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
			$uploadOk = 0;
		}
		// Check if $uploadOk is set to 0 by an error
		if ($uploadOk == 0) {
			echo "Sorry, your file was not uploaded.";
		// if everything is ok, try to upload file
		} else {
			if (move_uploaded_file($_FILES["foto"]["tmp_name"], $target_file)) {
				echo "The file ". basename($foto). " has been uploaded.";
				$sql="
				INSERT INTO user (
						 username,
						 password,
						 nama,
						 email,
						 pekerjaan,
						 gender,
						 foto
						 )
				VALUES 
						(
						'$username' ,
						'$password' ,
						'$nama' ,
						'$email' ,
						'$pekerjaan' ,
						'$gender' ,						
						'$target_file'	
						)";
				$query=mysqli_query($con,$sql) or die(mysqli_errno());
				
			} else {
				echo "Sorry, there was an error uploading your file.";
			}
		}
		
		
		
		break;
	}
	//Case Update Data
	//Case Delete Data
	
?>