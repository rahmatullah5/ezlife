<?php 
	$host="localhost";
	$username="root";
	$password="";
	$db="db_ezlife_ver0";
	$con=mysqli_connect($host,$username,$password,$db);
	
	session_name("ezlife");
	if(session_start()){
	}else{
		session_start();
	}
	
?>