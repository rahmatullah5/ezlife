<?php 
	include "../controller/connection.php";
 switch($_GET['p']){
	case 'landing_page':
		include "../view/landing_page.php";
	break;
	case 'home_page':
		include "../view/home_page.php";
	break;
	case 'user_profil':
		include "../view/user_profil.php";
	break;
	case 'user_register':
		include "../view/user_register.php";
	break;
 }
 
?>